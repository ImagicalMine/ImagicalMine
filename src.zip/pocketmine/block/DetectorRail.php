<?php

/*
 *
 *  _                       _           _ __  __ _             
 * (_)                     (_)         | |  \/  (_)            
 *  _ _ __ ___   __ _  __ _ _  ___ __ _| | \  / |_ _ __   ___  
 * | | '_ ` _ \ / _` |/ _` | |/ __/ _` | | |\/| | | '_ \ / _ \ 
 * | | | | | | | (_| | (_| | | (_| (_| | | |  | | | | | |  __/ 
 * |_|_| |_| |_|\__,_|\__, |_|\___\__,_|_|_|  |_|_|_| |_|\___| 
 *                     __/ |                                   
 *                    |___/                                                                     
 * 
 * This program is a third party build by ImagicalMine.
 * 
 * PocketMine is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author ImagicalMine Team
 * @link http://forums.imagicalcorp.ml/
 * 
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\entity\Minecart;
use pocketmine\Player;
use pocketmine\math\Vector3;

class DetectorRail extends ExtendedRailBlock implements RedstoneConsumer{

	protected $id = self::DETECTOR_RAIL;
	const SIDE_NORTH_WEST = 6;
	const SIDE_NORTH_EAST = 7;
	const SIDE_SOUTH_EAST = 8;
	const SIDE_SOUTH_WEST = 9;

	public function __construct(int $meta = 0){
		$this->meta = $meta;
	}

	public function getName() : string{
		return "Detector Rail";
	}

	public function getHardness() : int{
		return 0.1;
	}

	public function getToolType() : int{
		return Tool::TYPE_PICKAXE;
	}
	
	public function onUpdate($type){
		if($type === Level::BLOCK_UPDATE_SCHEDULED){
			if($this->meta === 1 && !$this->isEntityCollided()){
				$this->meta =0;
				$this->getLevel()->setBlock($this, Block::get($this->getId(), $this->meta), false, true, true);
				return Level::BLOCK_UPDATE_WEAK;
			}
		}
		if($type === Level::BLOCK_UPDATE_NORMAL){
			$this->getLevel()->scheduleUpdate($this, 50);
		}
		return false;
	}

	public function onEntityCollide(Entity $entity){
		if(!$this->isPowered()){
			$this->togglePowered();
		}
	}

	public function getDrops(Item $item) : array{
		return [[Item::DETECTOR_RAIL, 0, 1]];
	}

	public function isPowered() : bool{
		return (($this->meta & 0x01) === 0x01);
	}
	
	public function isEntityCollided() : bool{
		foreach ($this->getLevel()->getEntities() as $entity){
			if($entity instanceof Minecart && $this->getLevel()->getBlock($entity->getPosition()) === $this)
				return true;
		}
		return false;
	}

	/**
	 * Toggles the current state of this plate
	 */
	public function togglePowered(){
		$this->meta ^= 0x08;
		$this->isPowered()?$this->power=15:$this->power=0;
		$this->getLevel()->setBlock($this, $this, true, true);
	}

	public function setDirection($face, $isOnSlope = false){/*@Aodzip */
		$extrabitset=(($this->meta&0x08)===0x08);
		if($face !== Vector3::SIDE_WEST && $face !== Vector3::SIDE_EAST && $face !== Vector3::SIDE_NORTH && $face !== Vector3::SIDE_SOUTH){
			throw new IllegalArgumentException("This rail variant can't be on a curve!");
		}
		$this->meta=($extrabitset?($this->meta|0x08):($this->meta&~0x08));
		$this->getLevel()->setBlock($this, Block::get($this->id, $this->meta));
	}
	
	public function isCurve() : bool{
		return false;
	}
	
	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null) : bool{
		$down=$block->getSide(Vector3::SIDE_DOWN);
		if($down->isTransparent() === false){
			$this->getLevel()->setBlock($this, Block::get($this->id,0));
			$up=$block->getSide(Vector3::SIDE_UP);
			if($block->getSide(Vector3::SIDE_EAST)&&$block->getSide(Vector3::SIDE_WEST)){
				if($up->getSide(Vector3::SIDE_EAST)){
					$this->setDirection(Vector3::SIDE_EAST,true);
				}
				elseif($up->getSide(Vector3::SIDE_WEST)){
					$this->setDirection(Vector3::SIDE_WEST,true);
				}
				else{
					$this->setDirection(Vector3::SIDE_EAST);
				}
			}
			elseif($block->getSide(Vector3::SIDE_SOUTH)&&$block->getSide(Vector3::SIDE_NORTH)){
				if($up->getSide(Vector3::SIDE_SOUTH)){
					$this->setDirection(Vector3::SIDE_SOUTH,true);
				}
				elseif($up->getSide(Vector3::SIDE_NORTH)){
					$this->setDirection(Vector3::SIDE_NORTH,true);
				}
				else{
					$this->setDirection(Vector3::SIDE_SOUTH);
				}
			}
			else{
				$this->setDirection(Vector3::SIDE_NORTH);
			}
			return true;
		}
		return false;
	}

	public function getDirection() : bool{
		switch($this->meta){
			case 0:
				{
					return Vector3::SIDE_SOUTH;
				}
			case 1:
				{
					return Vector3::SIDE_EAST;
				}
			case 2:
				{
					return Vector3::SIDE_EAST;
				}
			case 3:
				{
					return Vector3::SIDE_WEST;
				}
			case 4:
				{
					return Vector3::SIDE_NORTH;
				}
			case 5:
				{
					return Vector3::SIDE_SOUTH;
				}
			case 6:
				{
					return self::SIDE_NORTH_WEST;
				}
			case 7:
				{
					return self::SIDE_NORTH_EAST;
				}
			case 8:
				{
					return self::SIDE_SOUTH_EAST;
				}
			case 9:
				{
					return self::SIDE_SOUTH_WEST;
				}
			default:
				{
					return Vector3::SIDE_SOUTH;
				}
		}
	}

	public function __toString() : string{
		$this->getName() . " facing " . $this->getDirection() . ($this->isCurve()?" on a curve ":($this->isOnSlope()?" on a slope":""));
	}

	public function isOnSlope() : bool{
		$d = $this->meta;
		return ($d == 0x02 || $d == 0x03 || $d == 0x04 || $d == 0x05);
	}
}